import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		String jsonStr = "{\r\n" + 
				"	\"poem\": [\r\n" + 
				"		{\r\n" + 
				"			\"item\": \"What is this life if, full of care,\"\r\n" + 
				"		},\r\n" + 
				"		{\r\n" + 
				"			\"item\": \"We have no time to stand and stare.\"\r\n" + 
				"		},\r\n" + 
				"		{\r\n" + 
				"			\"item\": \"No time to stand beneath the boughs\"\r\n" + 
				"		},\r\n" + 
				"		{\r\n" + 
				"			\"item\": \"And stare as long as sheep or cows.\"\r\n" + 
				"		},\r\n" + 
				"		{\r\n" + 
				"			\"item\": \"No time to see, when woods we pass,\"\r\n" + 
				"		},\r\n" + 
				"		{\r\n" + 
				"			\"item\": \"Where squirrels hide their nuts in grass.\"\r\n" + 
				"		},\r\n" + 
				"		{\r\n" + 
				"			\"item\": \"No time to see, in broad day light,\"\r\n" + 
				"		},\r\n" + 
				"		{\r\n" + 
				"			\"item\": \"Streams full of stars, like skies at night.\"\r\n" + 
				"		},\r\n" + 
				"		{\r\n" + 
				"			\"item\": \"No time to turn at beauty's glance,\"\r\n" + 
				"		},\r\n" + 
				"		{\r\n" + 
				"			\"item\": \"And watch her feet, how they can dance.\"\r\n" + 
				"		},\r\n" + 
				"		{\r\n" + 
				"			\"item\": \"No time to wait till her mouth can\"\r\n" + 
				"		},\r\n" + 
				"		{\r\n" + 
				"			\"item\": \"Enrich that smile her eyes began.\"\r\n" + 
				"		},\r\n" + 
				"		{\r\n" + 
				"			\"item\": \"A poor life this if, full of care,\"\r\n" + 
				"		},\r\n" + 
				"		{\r\n" + 
				"			\"item\": \"We have no time to stand and stare.\"\r\n" + 
				"		}\r\n" + 
				"	]\r\n" + 
				"}";
    	try {
    	Scanner sc = new Scanner(System.in);
    	System.out.println("Enter the keyword you are looking for:");
    	String str = sc.nextLine();
    	JSONParser jsonParser = new JSONParser();
    	JSONObject jsonObject = (JSONObject) jsonParser.parse(jsonStr);
    	JSONArray infoArray = (JSONArray) jsonObject.get("poem");
    	
           for(int i=0 ; i<infoArray.size() ; i++){
               JSONObject tempObj = (JSONObject) infoArray.get(i);
               //System.out.println(""+(i+1)+"번째 멤버의 이름 : "+tempObj.get("item"));
               String str2 = (String) tempObj.get("item");
               if(str2.contains(str)) {
            	   System.out.println("item "+(i)+": "+tempObj.get("item"));
               }
 
           }
    	} catch (ParseException e) {
    		 e.printStackTrace();
    	}

	}
}
